import React, {Component} from 'react';
class About extends Component {
    render() {
        return (
            <div>
                <h1 className='text-center'>About Us</h1>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris eget ultricies leo, ac mollis mauris. In condimentum quis erat et dapibus. Vestibulum sit amet diam fermentum, egestas mauris eget, tempus dui. Curabitur varius nulla id lacus iaculis, non volutpat lacus cursus. Nunc vel iaculis magna, ac suscipit metus. Ut maximus quis nunc vitae facilisis. Maecenas a malesuada dui, in feugiat lacus. Integer vitae cursus velit. Nam consectetur erat sed diam bibendum, ut facilisis urna imperdiet. Morbi eleifend risus ac elementum semper. Quisque dolor ipsum, finibus id tincidunt ac, efficitur nec nunc. Praesent vitae ornare ante. Sed porttitor iaculis dolor, ut bibendum erat aliquam sit amet.</p>

                <p>Phasellus accumsan ullamcorper euismod. Interdum et malesuada fames ac ante ipsum primis in faucibus. Fusce at nisi varius, sagittis massa in, elementum eros. Cras semper enim sed dolor malesuada, sit amet dictum lorem dictum. Phasellus posuere vel tellus varius fermentum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum vel mi convallis, placerat libero eu, semper quam. Vivamus sed arcu arcu. Pellentesque tincidunt in nulla eget consectetur. Proin blandit nisi ipsum, eu pretium lacus volutpat nec. Nunc aliquam risus ipsum, eu volutpat eros porttitor eu. Sed tristique metus ut nisl lacinia, ut faucibus lectus eleifend. Morbi ac ullamcorper turpis, a lobortis magna. Quisque ut vehicula eros. Phasellus a fermentum sem.</p>
            </div>
         )
    }
}

export default About;